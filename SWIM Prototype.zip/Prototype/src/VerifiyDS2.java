import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import com.adobe.livecycle.signatures.client.*;
import com.adobe.livecycle.signatures.client.types.*;
import com.adobe.livecycle.signatures.client.types.exceptions.InvalidArgumentException;
import com.adobe.livecycle.signatures.client.types.exceptions.MissingSignatureFieldException;
import com.adobe.livecycle.signatures.client.types.exceptions.PDFOperationException;
import com.adobe.livecycle.signatures.client.types.exceptions.PermissionsException;
import com.adobe.livecycle.signatures.client.types.exceptions.SignatureFieldNotSignedException;
import com.adobe.livecycle.signatures.client.types.exceptions.SignatureVerifyException;
import com.adobe.livecycle.signatures.pki.client.types.common.RevocationCheckStyle;
import com.adobe.idp.Document;
import com.adobe.idp.dsc.clientsdk.ServiceClientFactory;
import com.adobe.idp.dsc.clientsdk.ServiceClientFactoryProperties;

public class VerifiyDS2 {

	public static void main(String[] args) throws FileNotFoundException, MissingSignatureFieldException, InvalidArgumentException, PDFOperationException, SignatureFieldNotSignedException, SignatureVerifyException, PermissionsException, SignaturesOtherException {
		

			Properties connectionProps = new Properties();
			connectionProps.setProperty
			(ServiceClientFactoryProperties.DSC_DEFAULT_EJB_ENDPOINT, "jnp://hiro-xp:1099");
			connectionProps.setProperty
			(ServiceClientFactoryProperties.DSC_TRANSPORT_PROTOCOL,
			ServiceClientFactoryProperties.DSC_EJB_PROTOCOL);
			connectionProps.setProperty
			(ServiceClientFactoryProperties.DSC_SERVER_TYPE, "JBoss");
			connectionProps.setProperty
			(ServiceClientFactoryProperties.DSC_CREDENTIAL_USERNAME, "administrator");
			connectionProps.setProperty
			(ServiceClientFactoryProperties.DSC_CREDENTIAL_PASSWORD, "password");

			ServiceClientFactory myFactory = ServiceClientFactory.createInstance(connectionProps);

			SignatureServiceClient signClient = new SignatureServiceClient(myFactory);

			FileInputStream fileInputStream = new FileInputStream("C:\\Users\\Dominik Volz\\Desktop\\Test.pdf");
			Document inDoc = new Document(fileInputStream);

			String fieldName = "SignatureField1";

			PKIOptions pkiOptions = new PKIOptions();
			pkiOptions.setVerificationTime(VerificationTime.CURRENT_TIME);
			pkiOptions.setRevocationCheckStyle(RevocationCheckStyle.BestEffort);

			PDFSignatureVerificationInfo signInfo = signClient.verify2(inDoc, fieldName, pkiOptions, null);

			SignatureStatus sigStatus = signInfo.getStatus();
			String myStatus = "";

			if (sigStatus == SignatureStatus.DynamicFormSignatureUnknown)
				myStatus = "The signatures located in the dynamic PDF form are unknown";
			else if (sigStatus == SignatureStatus.DocumentSignatureUnknown)
				myStatus = "The signatures located in the PDF document are unknown";
			else if (sigStatus == SignatureStatus.CertifiedDynamicFormSignatureTamper)
				myStatus = "The signatures located in a certified PDF form are valid";
			else if (sigStatus == SignatureStatus.SignedDynamicFormSignatureTamper)
				myStatus = "The signatures located in a signed dynamic PDF form are valid";
			else if (sigStatus == SignatureStatus.CertifiedDocumentSignatureTamper)
				myStatus = "The signatures located in a certified PDF document are valid";
			else if (sigStatus == SignatureStatus.SignedDocumentSignatureTamper)
				myStatus = "The signatures located in a signed PDF document are valid";
			else if (sigStatus == SignatureStatus.SignatureFormatError)
				myStatus = "The format of a signature in a signed document is invalid";
			else if (sigStatus == SignatureStatus.DynamicFormSigNoChanges)
				myStatus = "No changes were made to the signed dynamic PDF form";
			else if (sigStatus == SignatureStatus.DocumentSigNoChanges)
				myStatus = "No changes were made to the signed PDF document";
			else if (sigStatus == SignatureStatus.DynamicFormCertificationSigNoChanges)
				myStatus = "No changes were made to the certified dynamic PDF form";
			else if (sigStatus == SignatureStatus.DocumentCertificationSigNoChanges)
				myStatus = "No changes were made to the certified PDF document";
			else if (sigStatus == SignatureStatus.DocSigWithChanges)
				myStatus = "There were changes to a signed PDF document";
			else if (sigStatus == SignatureStatus.CertificationSigWithChanges)
				myStatus = "There were changes made to the PDF document.";

			SignatureType sigType = signInfo.getSignatureType();
			String myType = "";

			if (sigType.getType() == PDFSignatureType.AUTHORSIG)
				myType = "Certification";
			else if (sigType.getType() == PDFSignatureType.RECIPIENTSIG)
				myType = "Recipient";

			IdentityInformation signerId = signInfo.getSigner();
			String signerMsg = "";

			if (signerId.getStatus() == IdentityStatus.UNKNOWN)
				signerMsg = "Identity Unknown";
			else if (signerId.getStatus() == IdentityStatus.TRUSTED)
				signerMsg = "Identity Trusted";
			else if (signerId.getStatus() == IdentityStatus.NOTTRUSTED)
				signerMsg = "Identity Not Trusted";

			SignatureProperties sigProps = signInfo.getSignatureProps();
			String signerName = sigProps.getSignerName();

			System.out.println("The status of the signature is: " + myStatus + ". The signer identity is " + signerMsg
					+ ". The signature type is " + myType + ". The name of the signer is " + signerName + ".");
		
	}

}